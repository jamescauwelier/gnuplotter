# GnuPlotter

Library to access gnuplot in rust. This currently focuses on exploratative work to find an acceptable API for my own project use-cases and is currently not aimed at a more general public.

