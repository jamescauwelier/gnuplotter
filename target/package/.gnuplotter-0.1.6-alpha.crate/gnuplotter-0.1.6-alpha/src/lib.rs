pub mod prelude {
    pub use gnuplotter_macros::*;
    pub use gnuplotter_core::prelude::*;
}