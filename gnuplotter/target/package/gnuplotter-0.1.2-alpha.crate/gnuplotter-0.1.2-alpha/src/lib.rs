#![deny(warnings)]
#![allow(dead_code, unused_imports)]

/// A sample documentation test
///
/// # Example
///
/// ```
/// assert!(true);
/// ```
fn hello() -> String {
    "Hello".into()
}